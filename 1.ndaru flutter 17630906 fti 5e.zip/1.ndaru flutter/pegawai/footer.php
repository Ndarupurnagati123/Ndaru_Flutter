</div>

<footer>
    <span>&copy; 2019 Ndaru Purnagati 17630906 - FTI UNISKA</div></span>
</footer>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
