<?php include"header.php" ?>
	<body background="img/St.jpg"></body>
	<div class="text-center">
		<img src="img/logo-uniska.png" width="200px" alt="UNISKA">
		<h2>WELCOME</h2>
		<marquee scrollamount="10" bgcolor="yellow">Tugas Flutter <code> VISUAL 3</code></marquee>
	</div>
<?php include"footer.php" ?>